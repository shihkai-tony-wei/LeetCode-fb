//
//  main.swift
//  FB-LeetCode
//
//  Created by Tony on 11/19/18.
//  Copyright © 2018 Tony. All rights reserved.
//

import Foundation

print("Hello, World!")

/* 67. Add Binary
 Given two binary strings, return their sum (also a binary string).
 
 The input strings are both non-empty and contains only characters 1 or 0.
 
 Example 1:
 
 Input: a = "11", b = "1"
 Output: "100"
 Example 2:
 
 Input: a = "1010", b = "1011"
 Output: "10101"
 */

func addBinary(_ a: String, b: String) -> String {
    var i = a.count - 1
    var j = b.count - 1
    
    var result = ""
    while i >= 0 || j >= 0 {
        
    }
}
