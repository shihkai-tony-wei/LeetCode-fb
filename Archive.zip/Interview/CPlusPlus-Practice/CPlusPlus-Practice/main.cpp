//
//  main.cpp
//  CPlusPlus-Practice
//
//  Created by Tony on 10/25/18.
//  Copyright © 2018 Tony. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
