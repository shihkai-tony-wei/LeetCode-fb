// 123 456 789
// 741 852 963
// col -> row
// row -> col: count - row
// 00, 01

import Foundation



var s = "A man, a plan, a canal: Panama"
let a = Array(s)

var dict = [Unicode.Scalar: Int]()
for c in s.unicodeScalars {
    dict[c, default: 0] += 1
}
dict


let set = CharacterSet.alphanumerics
let filtered = s.lowercased().unicodeScalars.filter { set.contains($0) }
Array(filtered)
Array(filtered.reversed())


let b = "abc"
b.utf8CString.count
b.count

func xxx(_ str: String) -> String {
    if str.isEmpty {
        return "1"
    }
    
    var result = ""
    var current: Character?
    var count = 0
    
    for c in str {
        if let cur = current {
            if c == cur {
                count += 1
            } else {
                result += "\(count)\(cur)"
                count = 1
                current = c
            }
        } else {
            current = c
            count += 1
        }
    }
    
    result += "\(count)\(current)"
    return result
}
public class ListNode {
    public var val: Int
    public var next: ListNode?
    public init(_ val: Int) {
        self.val = val
        self.next = nil
    }
}

func isPalindrome(_ head: ListNode?) -> Bool {
    var mid = head
    var it = head
    
    while it != nil {
        mid = mid?.next
        it = it?.next?.next
    }
    
    var rrHead = reverseList(nil, mid?.next)
    if rrHead == nil {
        return true
    }
    
    var start = head
    var rHead = rrHead
    
    while rHead != nil {
        if start?.val != rHead?.val {
            return false
        }
        rHead = rHead?.next
        start = start?.next
    }
    return true
}

func reverseList(_ head: ListNode?, _ next: ListNode?) -> ListNode? {
    if next == nil {
        return nil
    }
    let newHead = reverseList(next, next?.next)
    next?.next = head
    return newHead ?? next
}

var l1 = ListNode(0)
var l2 = ListNode(2)
l1.next = l2

isPalindrome(l1)
