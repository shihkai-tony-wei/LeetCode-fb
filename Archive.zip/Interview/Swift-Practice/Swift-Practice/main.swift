//
//  main.swift
//  Swift-Practice
//
//  Created by Tony on 10/25/18.
//  Copyright © 2018 Tony. All rights reserved.
//

import Foundation

print("Hello, World!")

public class TreeNode {
    public var val: Int
    public var left: TreeNode?
    public var right: TreeNode?
    public init(_ val: Int) {
        self.val = val
        self.left = nil
        self.right = nil
    }
}
 
class Solution {
    func maxDepth(_ root: TreeNode?) -> Int {
        return maxDepth3(root)
        return maxDepth2(root)
        return traverse(root, 0)
    }
    
    func traverse(_ root: TreeNode?, _ depth: Int) -> Int {
        if root == nil {
            return depth
        }
        let left = traverse(root?.left, depth + 1)
        let right = traverse(root?.right, depth + 1)
        return max(left, right)
    }
    
    func maxDepth2(_ root: TreeNode?) -> Int {
        if root == nil {
            return 0
        }
        return 1 + max(maxDepth2(root?.left), maxDepth2(root?.right))
    }
    
    func maxDepth3(_ root: TreeNode?) -> Int {
        guard let root = root else { return 0 }
        var queue = [root]
        var depth = 0
        while !queue.isEmpty {
            let rowNodeCount = queue.count
            for i in 0..<rowNodeCount {
                let n = queue.removeFirst()
                if let left = n.left {
                    queue.append(left)
                }
                if let right = n.right {
                    queue.append(right)
                }
            }
            depth += 1
        }
        return depth
    }
    
    // 0 1 2   3    4    5 6
    //[3,9,20,null,null,15,7]
    // 2*p + 1
    // 2*p + 2
    func convert(_ arr: [Int?], _ target: Int) -> TreeNode? {
        guard target < arr.count, let val = arr[target] else {
            return nil
        }
        let node = TreeNode(val)
        node.left = convert(arr, 2*target+1)
        node.right = convert(arr, 2*target+2)
        return node
    }
    
    
    func isValidBST(_ root: TreeNode?) -> Bool {
        if root == nil { return true }
        
        var pre: TreeNode? = nil
        var root = root
        var stack: [TreeNode] = []
        
        while root != nil || !stack.isEmpty {
            while root != nil {
                stack.append(root!)
                root = root?.left
            }
            
            let val = stack.removeLast()
            //print("\(val.val) ")
            if pre != nil && pre!.val >= val.val {
                return false
            }
            pre = val
            root = val.right
        }
        return true
    }
    
    
    func isSymmetric(_ root: TreeNode?) -> Bool {
        guard let root = root else { return true }
        
        var queue: [TreeNode] = []
        if let left = root.left {
            queue.append(left)
        }
        if let right = root.right {
            queue.append(right)
        }
        
        while !queue.isEmpty {
            if queue.count % 2 != 0 {
                return false
            }
            let left = queue.removeFirst()
            let right = queue.removeFirst()
            
            if left.val != right.val {
                return false
            }
            if left.left?.val != right.right?.val {
                return false
            }
            if left.right?.val != right.left?.val {
                return false
            }
            
            if left.left != nil {
                queue.append(left.left!)
            }
            if right.right != nil {
                queue.append(right.right!)
            }
            if left.right != nil {
                queue.append(left.right!)
            }
            if right.left != nil {
                queue.append(right.left!)
            }
        }
        return true
    }
    
    func isSymmetric2(_ root: TreeNode?) -> Bool {
        return _isSymmetric(root, root)
    }
    
    func _isSymmetric(_ left: TreeNode?, _ right: TreeNode?) -> Bool {
        if left == nil || right == nil {
            return left == nil && right == nil
        }
        if left?.val != right?.val {
            return false
        }
        return _isSymmetric(left?.left, right?.right) &&
               _isSymmetric(left?.right, right?.left)
    }
    
    
    func sortedArrayToBST(_ nums: [Int]) -> TreeNode? {
        if nums.count == 0 {
            return nil
        }
        if nums.count == 1 {
            return TreeNode(nums[0])
        }
        
        let mid = nums.count / 2
        let root = TreeNode(nums[mid])
        
        root.left = sortedArrayToBST(Array(nums[0..<mid]))
        if mid + 1 < nums.count {
            root.right = sortedArrayToBST(Array(nums[mid+1..<nums.count]))
        }
        return root
    }
    
}
let xxx = Array(repeating: true, count: 10)
xxx.filter({$0}).count


let s = Solution()
let tree = s.convert([1,2,3,3,nil,2,nil], 0)
//let ans = s.sortedArrayToBST([-10,-3,0,5,9])
let ans = 1 << 1
print("\(ans)")

func generate(_ numRows: Int) -> [[Int]] {
    if numRows <= 0 {
        return []
    }
    var result: [[Int]] = []
    
    var preRow: [Int] = []
    for i in 0..<numRows {
        var row = Array(repeating: 1, count: i+1)
        for j in stride(from: 1, to: row.count-1, by: +1) {
            row[j] = preRow[j-1] + preRow[j]
        }
        result.append(row)
        preRow = row
    }
    return result
}
print("\(generate(5))")

func maxSubArray(_ nums: [Int]) -> Int {
    if nums.count == 0 {
        return 0
    }
    return findMax(nums, 0, nums.count - 1)
}

func findMaxFromMid(_ nums: [Int], _ l: Int, _ m: Int, _ r: Int) -> Int {
    var left = Int.min
    var sum = 0
    for i in stride(from: m, through: l, by: -1) {
        sum += nums[i]
        left = max(left, sum)
    }
    var right = Int.min
    sum = 0
    for i in (m+1)...r {
        sum += nums[i]
        right = max(right, sum)
    }
    return left + right
}

func findMax(_ nums: [Int], _ l: Int, _ r: Int) -> Int {
    if l == r {
        return nums[l]
    }
    let m = l + (r-l)/2
    return max(findMax(nums, l, m), findMax(nums, m+1, r), findMaxFromMid(nums, l, m , r))
}

let ans2 = maxSubArray([-2, -5, 6, -2, -3, 1, 5, -6])
print("\(ans2)")

print("\([-2, -5, 6, -2, -3, 1, 5, -6].sorted())")

let str = "abc"
let g = str.utf8CString.reduce(0) {
    $0 + Int($1)
}
print("\(g)")

let yyy = [
    "b": [1,23,3],
    "a": [2, 4, 5]
]


func groupAnagrams(_ strs: [String]) -> [[String]] {
    var hash: [Int: [String]] = [:]
    for str in strs {
        var hh = Array(repeating: 0, count: 26)
        for code in str.unicodeScalars {
            let key = Int(code.value - 97)
            hh[key] += 1
        }
        print("\(hh.hashValue)")
    }
    var result: [[String]] = []
    return hash.map { $1 }
}

groupAnagrams(["cab","bac","pew","duh","may","ill","buy","bar","max","doc"])

//       0 1 2 3 4
// in:   2 3 1 2 3
//  count = 5
//   5-0 / 2  = 2
//   2 + (4-2)/2
//   0 + (2-0)/2
//  5 + (8-5)/2 = 6
//   7 + (8-7)/2
// pre:  1 2 3 2 3
// post: 3 2 3 2 1

// in:   3 2 4 1 4 2 3
// pre:  1 2 3 4 2 4 3
// post: 3 4 2 4 3 2 1


 // 2 3 1 3 2


func lengthOfLongestSubstring2(_ s: String) -> Int {
    var hash: [Character: Int] = [:] // c, index of c
    
    let arr = Array(s)
    var res = 0
    var start = 0
    for j in 0..<arr.count {
        let c = arr[j]
        if let pre = hash[c] {
            start = max(pre + 1, start)
        }
        res = max(res, j - start + 1)
        hash[c] = j
    }
    return res
}

func numIslands(_ grid: [[Character]]) -> Int {
    if grid.isEmpty {
        return 0
    }
    
    var result = 0
    var copy = grid
    for i in 0..<copy.count {
        for j in 0..<copy[i].count {
            if copy[i][j] == "1" {
                result += 1
                markIsland(&copy, i, j)
            }
        }
    }
    return result
}

func markIsland(_ grid: inout [[Character]], _ i: Int, _ j: Int)  {
    if i < 0 || i >= grid.count || j < 0 || j >= grid[i].count {
        return
    }
    
    
    grid[i][j] = "0"
    
    markIsland(&grid, i-1, j)
    markIsland(&grid, i+1, j)
    markIsland(&grid, i, j-1)
    markIsland(&grid, i, j+1)
}

// 0 1 2 3 4 5 6 7 8


//numIslands([["1","1","1","1","0"],["1","1","0","1","0"],["1","1","0","0","0"],["0","0","0","0","0"]])


func coinChange(_ coins: [Int], _ amount: Int) -> Int {
    var dp = Array(repeating: 0, count: amount + 1)
    var sum = 1
    
    while (sum <= amount) {
        
        var mini = -1
        for i in 0..<coins.count {
            let rem = sum - coins[i]
            if rem >= 0 && dp[rem] != -1 {
                let stored = dp[rem] + 1
                
                if mini != -1 {
                    mini = min(mini, stored)
                } else {
                    mini = stored
                }
            }
        }
        dp[sum] = mini
        sum += 1
    }
    return dp.last!
}
//coinChange([1,2,5], 11)


func isHappy(_ n: Int) -> Bool {
    var sum = 0
    var n = n
    
    var s = Set<Int>()
    while true {
        let r = n % 10
        sum += r*r
        
        n = n / 10
        if n == 0 {
            n = sum
            if sum == 1 {
                return true
            }
            let result = s.insert(sum)
            if result.0 == false {
                return false
            }
            sum = 0
        }
    }
    
    return true
}

let sss = "ssssa"
for u in sss.unicodeScalars.reversed().enumerated() {
    print("\(u)")
}
let zzz: Int = NSDecimalNumber(decimal: pow(Decimal(26), 8)).intValue
isHappy(19)


func myPow(_ x: Double, _ n: Int) -> Double {
    if n == 0 {
        return 1
    }
    var x = n < 0 ? 1/x : x
    let n = abs(n)
    var sum = x
    for i in 0..<(n-1) {
        sum *= x
    }
    return sum
}

//let ggg = myPow(2, 10)

func divide(_ dividend: Int, _ divisor: Int) -> Int {
    var val = dividend
    var div = divisor
    var result = 0
    while val >= div {
        var tmp = div
        var mlt = 1
        while val > (tmp << 1) {
            tmp = tmp << 1
            mlt = mlt << 1
        }
        
        val = val - tmp
        result += mlt
    }
    
    
    return result
}
divide(15, 3)


func productExceptSelf(_ nums: [Int]) -> [Int] {
    var results = Array(repeating: 1, count: nums.count)
    
    var tmp = 1
    for i in 0..<nums.count {
        results[i] *= tmp
        tmp *= nums[i]
    }
    tmp = 1
    for i in stride(from: nums.count - 1, through: 0, by: -1) {
        results[i] *= tmp
        tmp *= nums[i]
    }
    return results
}

print(productExceptSelf([1,2,3,4]))

func isDeadOfLive(_ board: inout [[Int]], _ i: Int, _ j: Int) -> Bool {
    let m = board.count
    let n = board[0].count
    
    var neighbor = 0
    for a in i-1...i+1 {
        for b in j-1...j+1 {
            if a >= 0 && a < m && b >= 0 && b < n && (a != i || b != j) {
                if board[a][b] == 1 {
                    neighbor += 1
                }
            }
        }
    }
    return neighbor == 3 || (board[i][j] == 1 && neighbor >= 2 && neighbor <= 3)
}

func gameOfLife(_ board: inout [[Int]]) {
    let m = board.count
    if m == 0 {
        return
    }
    let n = board[0].count
    if n == 0 {
        return
    }
    
    var copy = board
    for i in 0..<copy.count {
        for j in 0..<copy[i].count {
            board[i][j] = isDeadOfLive(&copy, i, j) ? 1 : 0
        }
    }
    
}
var b = [[0,1,0],[0,0,1],[1,1,1],[0,0,0]]
gameOfLife(&b)
print(b)


func calculate(_ s: String) -> Int {
    var result = 0
    var holding = 0
    
    var processHighOrder = ""
    var lastSign = true
    
    for c in s {
        if c == " " {
            continue
        }
        
        switch c {
        case " ":
            continue
        case "1", "2", "3", "4", "5", "6", "7", "8", "9", "0":
            
            let num = Int(String(c))!
            switch processHighOrder {
            case "*":
                holding = holding * num
            case "/":
                holding = holding / num
            default:
                holding = num
            }
        case "+":
            processHighOrder = ""
            result += holding
            holding = 0
            lastSign = true
        case "-":
            processHighOrder = ""
            if lastSign == false {
                result -= holding
            } else {
                result += holding
            }
            holding = 0
            lastSign = false
        case "*":
            processHighOrder = "*"
            
        case "/":
            processHighOrder = "/"
        default:
            break
        }
    }
    
    return lastSign ? result + holding : result - holding
    
}
print(Array("abc"))
//calculate("1*2-3/4+5*6-7*8+9/10")


func minWindow(_ s: String, _ t: String) -> String {
    var hash: [String: Int] = [:]
    var counter = t.count
    var start = 0
    var end = 0
    var head = 0
    var length = Int.max
    
    let tAry = t.map { String($0) }
    for c in tAry {
        hash[c, default: 0] += 1
    }
    let sAry = s.map { String($0) }
    
    while end < sAry.count {
        let cur = sAry[end]
        if let ocr = hash[cur], ocr > 0 {
            counter -= 1
        }
        hash[cur, default: 0] -= 1
        end += 1
        
        while counter == 0 {
            if length > (end - start) {
                length = end - start
                head = start
            }
            
            // moving start
            let ccur = sAry[start]
            if let ocr = hash[ccur], ocr == 0 {
                counter += 1
            }
            hash[ccur, default: 0] += 1
            start += 1
        }
    }
    if length == Int.max {
        return ""
    }
    
    let subSAry = sAry[head..<(head+length)]
    var result = ""
    for c in subSAry {
        result += c
    }
    return result
    
}
print("\(minWindow("ab", "a"))")

public class ListNode {
   public var val: Int
    public var next: ListNode?
         public init(_ val: Int) {
                 self.val = val
                     self.next = nil
            }
}

func sortList(_ head: ListNode?) -> ListNode? {
    var done = head == nil
    var step = 1
    var head = head
    
    
    while !done {
        var last: ListNode? = nil
        var newHead: ListNode? = nil
        var walker = newHead ?? head
        while walker != nil {
            var subList: [ListNode?] = [nil, nil]
            for sIndex in 0..<subList.count {
                subList[sIndex] = walker
                for i in 0..<step {
                    let next = walker?.next
                    if i == step-1 {
                        walker?.next = nil
                    }
                    walker = next
                }
            }
            
            let tuple = merge(subList[0], subList[1])
            if newHead == nil {
                newHead = tuple.0
                if walker == nil {
                    done = true
                }
            }
            last?.next = tuple.0
            tuple.1?.next = walker
            last = tuple.1
        }
        head = newHead
        step = step * 2
    }
    return head
}

func merge(_ a: ListNode?, _ b: ListNode?) -> (ListNode?, ListNode?) {
    var a = a
    var b = b
    
    var head: ListNode? = nil
    var cur: ListNode? = nil
    
    while a != nil || b != nil {
        var next: ListNode? = nil
        
        if a != nil && b != nil {
            if a!.val < b!.val {
                next = a
                a = a!.next
            } else {
                next = b
                b = b!.next
            }
        } else if a != nil{
            next = a
            a = a!.next
        } else {
            next = b
            b = b!.next
        }
        
        if cur == nil {
            cur = next
        } else {
            cur?.next = next
            cur = next
        }
        if head == nil {
            head = cur
        }
    }
    return (head, cur)
}

let ln1 = ListNode(0)
let ln2 = ListNode(4)
let ln3 = ListNode(3)
let ln4 = ListNode(5)
let ln5 = ListNode(-1)


let head = ln5
ln5.next = ln4
ln4.next = ln3
ln3.next = ln2
ln2.next = ln1

sortList(head)




func maxSubArray(_ A: [Int], _ i: Int, _ j: Int) -> Int {
    if i >= j {
        return A[i]
    }
    
    let m = i + (j-i)/2
    let left = maxSubArray(A, i, m)
    let right = maxSubArray(A, m+1, j)
    
    var sum = 0
    var leftMax = Int.min
    for a in stride(from: m, through: i, by: -1) {
        sum += A[a]
        leftMax = max(leftMax, sum)
    }
    sum = 0
    var rightMax = Int.min
    for a in stride(from: m+1, through: j, by: +1) {
        sum += A[a]
        rightMax = max(rightMax, sum)
    }
    return max(left, right, rightMax+leftMax)
    
}

print(maxSubArray([-2,1,-3,4,-1,2,1,-5,4], 0, 8))
