//
//  ViewController.swift
//  iOS-Practice
//
//  Created by Tony on 10/25/18.
//  Copyright © 2018 Tony. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {

    @IBOutlet weak var collectionView: UICollectionView!
    
    let data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    
    var doReload = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        collectionView.backgroundColor = .yellow
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            
            let vc = UIViewController()
            vc.view.backgroundColor = .green
            
            self.present(vc, animated: true) {
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                    self.doReload = true
                    self.collectionView.reloadData()
                }
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                    self.dismiss(animated: false, completion: nil)
                }
            }
        }
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        print("bbb")
        return doReload == false ? 0 : data.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        print("aaa")
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        return cell
    }
    

}

